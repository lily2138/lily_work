package park.vo;

public class Fix {
	private int attrNo;
	private int empNo;

	public Fix(int attrNo, int empNo) {
		super();
		this.attrNo = attrNo;
		this.empNo = empNo;
	}
	public int getAttrNo() {
		return attrNo;
	}
	public void setAttrNo(int attrNo) {
		this.attrNo = attrNo;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
}
