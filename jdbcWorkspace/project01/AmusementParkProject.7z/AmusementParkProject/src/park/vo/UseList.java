package park.vo;

public class UseList {
	private int custNo;
	private int attrNo;
	private String useDate;
	
	public UseList(int custNo, int attrNo, String useDate) {
		super();
		this.custNo = custNo;
		this.attrNo = attrNo;
		this.useDate = useDate;
	}

	public int getCustNo() {
		return custNo;
	}

	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}

	public int getAttrNo() {
		return attrNo;
	}

	public void setAttrNo(int attrNo) {
		this.attrNo = attrNo;
	}

	public String getUseDate() {
		return useDate;
	}

	public void setUseDate(String useDate) {
		this.useDate = useDate;
	}
	
	

}
