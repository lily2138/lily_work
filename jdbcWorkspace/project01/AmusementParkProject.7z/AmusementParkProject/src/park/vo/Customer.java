package park.vo;

public class Customer {
	private int custNo;
	private String sex;
	private int age;
	private int type;

	public Customer(int custNo, String sex, int age, int type) {
		super();
		this.custNo = custNo;
		this.sex = sex;
		this.age = age;
		this.type = type;
	}

	public int getCustNo() {
		return custNo;
	}

	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Customer [custNo=" + custNo + ", sex=" + sex + ", age=" + age + ", type=" + type + "]";
	}
}
