package park.vo;

public class Attraction {

	private int attrnNo;
	private String attrName;
	private String repairDate;
	private int attrPrice;
	private int attrCost;

	public Attraction(int attrnNo, String attrName, String repairDate, int attrPrice, int attrCost) {
		super();
		this.attrnNo = attrnNo;
		this.attrName = attrName;
		this.repairDate = repairDate;
		this.attrPrice = attrPrice;
		this.attrCost = attrCost;
	}

	public int getAttrnNo() {
		return attrnNo;
	}

	public void setAttrnNo(int attrnNo) {
		this.attrnNo = attrnNo;
	}

	public String getAttrName() {
		return attrName;
	}

	public void setAttrName(String attrName) {
		this.attrName = attrName;
	}

	public String getRepairDate() {
		return repairDate;
	}

	public void setRepairDate(String repairDate) {
		this.repairDate = repairDate;
	}

	public int getAttrPrice() {
		return attrPrice;
	}

	public void setAttrPrice(int attrPrice) {
		this.attrPrice = attrPrice;
	}

	public int getAttrCost() {
		return attrCost;
	}

	public void setAttrCost(int attrCost) {
		this.attrCost = attrCost;
	}

	@Override
	public String toString() {
		return "Attraction [attrnNo=" + attrnNo + ", attrName=" + attrName + ", repairDate=" + repairDate
				+ ", attrPrice=" + attrPrice + ", attrCost=" + attrCost + "]";
	}
}
