package park.command;

import java.sql.SQLException;

import park.dao.DefaultDaoImpl;
import park.resource.StrResource;
import park.vo.Attraction;
import park.vo.Employee;

public class UpdateCmd implements Command {
	private DefaultDaoImpl dao = DefaultDaoImpl.getInstance();
	private int selected;
	private Object vo;

	public UpdateCmd(Object vo) {
		this.vo = vo;
	}

	@Override
	public void setSeleted(int selected) {
		this.selected = selected;
	}

	@Override
	public Object execute() throws SQLException {
		if (StrResource.UPDATE_EMPLOYEE.getIntValue() == selected)
			return dao.updateEmployee((Employee) vo);
		else if (StrResource.UPDATE_ATTRACTION.getIntValue() == selected)
			return dao.updateAttraction((Attraction) vo);

		return null;
	}
}
