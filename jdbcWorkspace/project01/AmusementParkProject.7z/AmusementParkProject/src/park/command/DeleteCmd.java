package park.command;

import java.sql.SQLException;

import park.dao.DefaultDaoImpl;
import park.vo.Employee;

public class DeleteCmd implements Command {
	private DefaultDaoImpl dao = DefaultDaoImpl.getInstance();
	private int selected;
	private Object vo;

	public DeleteCmd(Object vo) {
		this.vo = vo;
	}

	@Override
	public void setSeleted(int selected) {
		this.selected = selected;
	}

	@Override
	public Object execute() throws SQLException {
		return dao.deleteEmployee(((Employee) vo).getEmpNo());
	}

}
