package park.command;

import java.sql.SQLException;

import park.dao.DefaultDaoImpl;
import park.resource.StrResource;
import park.vo.Attraction;
import park.vo.Customer;
import park.vo.Employee;

public class SelectCmd implements Command {
	private DefaultDaoImpl dao = DefaultDaoImpl.getInstance();
	private int selected;
	private Object vo;

	public SelectCmd(Object vo) {
		this.vo = vo;
	}

	@Override
	public void setSeleted(int selected) {
		this.selected = selected;
	}

	@Override
	public Object execute() throws SQLException {
		if (StrResource.SELECT_CUSTOMER.getIntValue() == selected)
			return dao.selectCustomer(((Customer) vo).getCustNo());
		else if (StrResource.SELECT_EMPLOYEE.getIntValue() == selected)
			return dao.selectEmployee(((Employee) vo).getEmpNo());
		else if (StrResource.SELECT_ATTREACTION.getIntValue() == selected)
			return dao.selectAttraction(((Attraction) vo).getAttrnNo());
		else if (StrResource.SELECT_CUSTOMER_ALL.getIntValue() == selected)
			return dao.selectCustomerALL();
		else if (StrResource.SELECT_EMPLOYEE_ALL.getIntValue() == selected)
			return dao.selectEmployeeALL();
		else if (StrResource.SELECT_ATTREACTION_ALL.getIntValue() == selected)
			return dao.selectAttractionALL();

		return null;
	}
}
