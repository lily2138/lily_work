package park.view;

public class ConsoleView {
	public void show(String result) {
		System.out.println(result);
	}
}
