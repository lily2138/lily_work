package park.client;

import java.sql.SQLException;
import java.util.Scanner;

import park.controller.FrontController;
import park.view.ConsoleView;
import park.vo.Attraction;
import park.vo.Customer;
import park.vo.Employee;

public class EncoreLandClient {

	public static void main(String[] args) throws SQLException {
		ConsoleView view = new ConsoleView();
		FrontController controller = new FrontController(view);

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("\nINSERT 1.손님\t2.직원\t3.기구\n" 
					+ "DELETE 4.직원삭제\n" 
					+ "UPDATE 5.직원수정\t6.기구수정\n"
					+ "SELECT 7.손님\t8.직원\t9.기구\n" 
					+ "SELECT ALL 10.손님\t11.직원\t12.기구\n");
			
			int selected = sc.nextInt();
			controller.setSeleted(selected);

			switch (selected) {
			case 1:
				System.out.println("성별");
				String sex = sc.next();
				System.out.println("나이");
				int age = sc.nextInt();
				System.out.println("이용권");
				int type = sc.nextInt();
				controller.setVo(new Customer(0, sex, age, type));
				break;
			case 2:
				System.out.println("이름");
				String empName = sc.next();
				System.out.println("부서");
				String dept = sc.next();
				controller.setVo(new Employee(0, empName, dept));
				break;
			case 3:
				System.out.println("기구이름");
				String attrName = sc.next();
				System.out.println("점검일");
				String repairDate = sc.next();
				System.out.println("이용가격");
				int attrPrice = sc.nextInt();
				System.out.println("유지비용");
				int attrCost = sc.nextInt();
				controller.setVo(new Attraction(0, attrName, repairDate, attrPrice, attrCost));
				break;
			case 4:
				System.out.println("직원 번호");
				int empNo = sc.nextInt();
				controller.setVo(new Employee(empNo, null, null));
				break;
			case 5:
				System.out.println("번호");
				int empNo2 = sc.nextInt();
				System.out.println("이름");
				String empName2 = sc.next();
				System.out.println("부서");
				String dept2 = sc.next();
				controller.setVo(new Employee(empNo2, empName2, dept2));
				break;
			case 6:
				System.out.println("번호");
				int attrnNo = sc.nextInt();
				System.out.println("기구이름");
				String attrName2 = sc.next();
				System.out.println("점검일");
				String repairDate2 = sc.next();
				System.out.println("이용가격");
				int attrPrice2 = sc.nextInt();
				System.out.println("유지비용");
				int attrCost2 = sc.nextInt();
				controller.setVo(new Attraction(attrnNo, attrName2, repairDate2, attrPrice2, attrCost2));
				break;
			case 7:
				System.out.println("번호");
				int custNo = sc.nextInt();
				controller.setVo(new Customer(custNo, null, 0, 0));
				break;
			case 8:
				System.out.println("번호");
				int empNo3 = sc.nextInt();
				controller.setVo(new Employee(empNo3, null, null));
				break;
			case 9:
				System.out.println("번호");
				int attrnNo2 = sc.nextInt();
				controller.setVo(new Attraction(attrnNo2, null, null, 0, 0));
				break;
			case 10:
				controller.setVo(new Customer(0, null, 0, 0));
				break;
			case 11:
				controller.setVo(new Employee(0, null, null));
				break;
			case 12:
				controller.setVo(new Attraction(0, null, null, 0, 0));
				break;
			default:
				continue;
			}
			
			controller.actionDo();
		}
	}
}
