package park.resource;

public enum StrResource {
	REQUEST_SUCCESS(200, "성공적으로 처리되었습니다."), REQUEST_FAILED(500, "요청에 실패하였습니다."),

	INSERT_CUSTOMER(1, "INSERT INTO customer VALUES(null, ?, ?, ?)"),
	INSERT_EMPLOYEE(2, "INSERT INTO employee VALUES(null, ?, ?)"),
	INSERT_ATTRACTION(3, "INSERT INTO attraction VALUES(null, ?, ?, ?, ?)"),

	DELETE_EMPLOYEE(4, "DELETE FROM employee WHERE no = ?"),

	UPDATE_EMPLOYEE(5, "UPDATE employee SET name = ?, dept = ? WHERE no = ?"),
	UPDATE_ATTRACTION(6, "UPDATE attraction SET name = ?, repairdate = ?, price = ?, cost = ? WHERE no = ?"),

	SELECT_CUSTOMER(7, "SELECT * FROM customer where no = ?"), 
	SELECT_EMPLOYEE(8, "SELECT * FROM employee where no = ?"),
	SELECT_ATTREACTION(9, "SELECT * FROM attraction where no = ?"),
	SELECT_CUSTOMER_ALL(10, "SELECT * FROM customer"),
	SELECT_EMPLOYEE_ALL(11, "SELECT * FROM employee"),
	SELECT_ATTREACTION_ALL(12, "SELECT * FROM attraction");

	private int intValue;
	private String strValue;

	private StrResource(int intValue, String strValue) {
		this.intValue = intValue;
		this.strValue = strValue;
	}

	public int getIntValue() {
		return intValue;
	}

	public String getStrValue() {
		return strValue;
	}

}
