package park.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import park.vo.Attraction;
import park.vo.Customer;
import park.vo.Employee;

public interface DefaultDao {
	public Connection getConnect() throws SQLException;

	public void closeAll(PreparedStatement ps, Connection conn) throws SQLException;

	public void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException;

	int insertCustomer(Customer vo) throws SQLException;

	int insertEmployee(Employee vo) throws SQLException;

	int insertAttraction(Attraction vo) throws SQLException;

	int deleteEmployee(int empNo) throws SQLException;

	int updateEmployee(Employee emp) throws SQLException;

	int updateAttraction(Attraction attr) throws SQLException;

	ArrayList<Customer> selectCustomerALL() throws SQLException;

	Customer selectCustomer(int id) throws SQLException;

	ArrayList<Employee> selectEmployeeALL() throws SQLException;

	Employee selectEmployee(int id) throws SQLException;

	ArrayList<Attraction> selectAttractionALL() throws SQLException;

	Attraction selectAttraction(int id) throws SQLException;
}
