package park.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import park.resource.StrResource;
import park.vo.Attraction;
import park.vo.Customer;
import park.vo.Employee;

public class DefaultDaoImpl implements DefaultDao {

	private static DefaultDaoImpl dao = new DefaultDaoImpl();

	private DefaultDaoImpl() {

	}

	public static DefaultDaoImpl getInstance() {
		return dao;
	}

	@Override
	public Connection getConnect() throws SQLException {
		Connection conn = null;
		try {
			Properties p = new Properties();
			p.load(new FileInputStream("src/config/jdbc.properties"));
			String driverName = p.getProperty("jdbc.mysql.driver");
			String url = p.getProperty("jdbc.mysql.url");
			String user = p.getProperty("jdbc.mysql.user");
			String pass = p.getProperty("jdbc.mysql.pass");
			Class.forName(driverName);
			conn = DriverManager.getConnection(url, user, pass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public void closeAll(PreparedStatement ps, Connection conn) throws SQLException {
		if (ps != null)
			ps.close();
		if (conn != null)
			conn.close();
	}

	@Override
	public void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException {
		if (rs != null)
			rs.close();
		closeAll(ps, conn);
	}

	@Override
	public int insertCustomer(Customer vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.INSERT_CUSTOMER.getStrValue());
			ps.setString(1, vo.getSex());
			ps.setInt(2, vo.getAge());
			ps.setInt(3, vo.getType());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public int insertEmployee(Employee vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.INSERT_EMPLOYEE.getStrValue());
			ps.setString(1, vo.getEmpName());
			ps.setString(2, vo.getDept());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public int insertAttraction(Attraction vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.INSERT_ATTRACTION.getStrValue());
			ps.setString(1, vo.getAttrName());
			ps.setString(2, vo.getRepairDate());
			ps.setInt(3, vo.getAttrPrice());
			ps.setInt(4, vo.getAttrCost());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	// alter table fix add constraint employee_no foreign key (employee_no)
	// References employee(no) on delete cascade;
	@Override
	public int deleteEmployee(int empNo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.DELETE_EMPLOYEE.getStrValue());
			ps.setInt(1, empNo);
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public int updateEmployee(Employee emp) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.UPDATE_EMPLOYEE.getStrValue());
			ps.setString(1, emp.getEmpName());
			ps.setString(2, emp.getDept());
			ps.setInt(3, emp.getEmpNo());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public int updateAttraction(Attraction attr) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.UPDATE_ATTRACTION.getStrValue());
			ps.setString(1, attr.getAttrName());
			ps.setString(2, attr.getRepairDate());
			ps.setInt(3, attr.getAttrPrice());
			ps.setInt(4, attr.getAttrCost());
			ps.setInt(5, attr.getAttrnNo());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public Customer selectCustomer(int id) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Customer customer = null;

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_CUSTOMER.getStrValue());
		ps.setInt(1, id);
		rs = ps.executeQuery();
		if (rs.next())
			customer = new Customer(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4));
		closeAll(rs, ps, conn);
		return customer;
	}

	@Override
	public Employee selectEmployee(int id) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Employee employee = null;

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_EMPLOYEE.getStrValue());
		ps.setInt(1, id);
		rs = ps.executeQuery();
		if (rs.next())
			employee = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3));
		closeAll(rs, ps, conn);
		return employee;
	}

	@Override
	public Attraction selectAttraction(int id) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Attraction attraction = null;

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_ATTREACTION.getStrValue());
		ps.setInt(1, id);
		rs = ps.executeQuery();
		if (rs.next())
			attraction = new Attraction(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5));
		closeAll(rs, ps, conn);
		System.out.println("실행");
		return attraction;
	}

	@Override
	public ArrayList<Customer> selectCustomerALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Customer> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_CUSTOMER_ALL.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Customer(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4)));
		closeAll(rs, ps, conn);
		return arr;
	}

	@Override
	public ArrayList<Employee> selectEmployeeALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Employee> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_EMPLOYEE_ALL.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3)));
		closeAll(rs, ps, conn);
		return arr;
	}

	@Override
	public ArrayList<Attraction> selectAttractionALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Attraction> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_ATTREACTION_ALL.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Attraction(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5)));
		closeAll(rs, ps, conn);
		return arr;
	}
}
