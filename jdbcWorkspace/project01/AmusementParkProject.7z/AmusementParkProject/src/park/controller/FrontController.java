package park.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import park.command.Command;
import park.command.DeleteCmd;
import park.command.InsertCmd;
import park.command.SelectCmd;
import park.command.UpdateCmd;
import park.resource.StrResource;
import park.view.ConsoleView;
import park.vo.Attraction;
import park.vo.Customer;
import park.vo.Employee;

public class FrontController {
	private ConsoleView view;
	private int selected;
	private Object vo;
	private Object result;

	public FrontController(ConsoleView view) {
		this.view = view;
	}

	public void setSeleted(int selected) {
		this.selected = selected;
	}

	public void setVo(Object vo) {
		this.vo = vo;
	}

	public void actionDo() throws SQLException {
		Command cmd = null;
		if (selected <= 3)
			cmd = new InsertCmd(vo);

		else if (selected <= 4)
			cmd = new DeleteCmd(vo);

		else if (selected <= 6)
			cmd = new UpdateCmd(vo);

		else if (selected <= 12)
			cmd = new SelectCmd(vo);

		cmd.setSeleted(selected);
		result = cmd.execute();
		updateView();
	}

	private void updateView() {
		if (result instanceof Integer) {
			if ((int) result == 200)
				view.show(StrResource.REQUEST_SUCCESS.getStrValue());
			else
				view.show(StrResource.REQUEST_FAILED.getStrValue());
		} else {
			if (result.getClass() == ArrayList.class) {
				ArrayList<?> arr = (ArrayList<?>) result;
				if (arr.size() != 0)
					for (Object o : arr)
						if (arr.get(0).getClass() == Customer.class)
							view.show(((Customer) o).toString());
						else if (arr.get(0).getClass() == Employee.class)
							view.show(((Employee) o).toString());
						else if (arr.get(0).getClass() == Attraction.class)
							view.show(((Attraction) o).toString());
			} else {
				if (result.getClass() == Customer.class)
					view.show(((Customer) result).toString());
				else if (result.getClass() == Employee.class)
					view.show(((Employee) result).toString());
				else if (result.getClass() == Attraction.class)
					view.show(((Attraction) result).toString());
			}
		}
	}
}
