package park.client;

import java.sql.SQLException;
import java.util.Scanner;

import park.controller.FrontController;
import park.view.ConsoleView;
import park.vo.Attraction;
import park.vo.Customer;
import park.vo.UseList;

public class EncoreLandClient {

	public static void main(String[] args) throws SQLException {
		ConsoleView view = new ConsoleView();
		FrontController controller = new FrontController(view);

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("\nINSERT 1.손님\t2.결제\n" 
					+ "UPDATE 3.손님\n" 
					+ "DELETE 4.결제취소\n"
					+ "SELECT 5.손님\t6.기구\n" 
					+ "SELECT ALL 7.결제\t8.기구\n"
					+ "ANALYSIS 9.기구\t10.나이\t11.성별");
			
			int selected = sc.nextInt();
			controller.setSeleted(selected);

			switch (selected) {
			case 1:
				System.out.println("성별");
				String sex = sc.next();
				System.out.println("나이");
				int age = sc.nextInt();
				controller.setVo(new Customer(0, sex, age));
				break;
			case 2:
				System.out.println("손님");
				int custNo = sc.nextInt();
				System.out.println("기구");
				int attrNo = sc.nextInt();
				System.out.println("날짜");
				String useDate = sc.next();
				System.out.println("상태");
				int status = sc.nextInt();
				controller.setVo(new UseList(0, custNo, attrNo, useDate, status));
				break;
			case 3:
				System.out.println("번호");
				int custNo1 = sc.nextInt();
				System.out.println("성별");
				String sex2 = sc.next();
				System.out.println("나이");
				int age2 = sc.nextInt();
				controller.setVo(new Customer(custNo1, sex2, age2));
				break;
			case 4:
				System.out.println("고객");
				int custNo2 = sc.nextInt();
				System.out.println("기구");
				int attrNo2 = sc.nextInt();
				controller.setVo(new UseList(0, custNo2, attrNo2, null, 0));
				break;
			case 5:
				System.out.println("번호");
				int custNo3 = sc.nextInt();
				controller.setVo(new Customer(custNo3, null, 0));
				break;
			case 6:
				System.out.println("번호");
				int attrNo3 = sc.nextInt();
				controller.setVo(new Attraction(attrNo3, null, 0, 0, null));
				break;
			case 7:
				break;
			case 8:
				break;
			case 9:
				break;
			case 10:
				break;
			case 11:
				break;
			default:
				continue;
			}
			controller.actionDo();
		}
	}
}
