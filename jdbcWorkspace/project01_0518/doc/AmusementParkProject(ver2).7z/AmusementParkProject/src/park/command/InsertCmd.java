package park.command;

import java.sql.SQLException;

import park.dao.DefaultDaoImpl;
import park.resource.StrResource;
import park.vo.Customer;
import park.vo.UseList;

public class InsertCmd implements Command {
	private DefaultDaoImpl dao = DefaultDaoImpl.getInstance();
	private int selected;
	private Object vo;

	public InsertCmd(Object vo) {
		this.vo = vo;
	}

	@Override
	public void setSeleted(int selected) {
		this.selected = selected;
	}

	@Override
	public Object execute() throws SQLException {
		if (StrResource.INSERT_CUSTOMER.getIntValue() == selected)
			return dao.insertCustomer((Customer) vo);
		else if (StrResource.INSERT_USELIST.getIntValue() == selected)
			return dao.insertUseList((UseList) vo);
		return null;
	}
}
