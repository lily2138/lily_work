package park.command;

import java.sql.SQLException;

public interface Command {
	void setSeleted(int selected);

	Object execute() throws SQLException;
}
