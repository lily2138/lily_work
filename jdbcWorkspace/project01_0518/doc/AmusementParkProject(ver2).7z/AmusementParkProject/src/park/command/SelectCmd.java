package park.command;

import java.sql.SQLException;

import park.dao.DefaultDaoImpl;
import park.resource.StrResource;
import park.vo.Attraction;
import park.vo.Customer;

public class SelectCmd implements Command {
	private DefaultDaoImpl dao = DefaultDaoImpl.getInstance();
	private int selected;
	private Object vo;

	public SelectCmd(Object vo) {
		this.vo = vo;
	}

	@Override
	public void setSeleted(int selected) {
		this.selected = selected;
	}

	@Override
	public Object execute() throws SQLException {
		if (StrResource.SELECT_CUSTOMER.getIntValue() == selected)
			return dao.selectCustomer(((Customer) vo).getCustNo());
		else if (StrResource.SELECT_ATTREACTION.getIntValue() == selected)
			return dao.selectAttraction(((Attraction) vo).getAttrNo());
		else if (StrResource.SELECT_ATTREACTION_ALL.getIntValue() == selected)
			return dao.selectAttractionALL();
		else if (StrResource.SELECT_USELIST_ALL.getIntValue() == selected)
			return dao.selectUseListALL();
		else if (StrResource.SELECT_RANK_ATTR.getIntValue() == selected)
			return dao.selectRankAttrALL();
		else if (StrResource.SELECT_RANK_AGE.getIntValue() == selected)
			return dao.selectRankAgeALL();
		else if (StrResource.SELECT_RANK_SEX.getIntValue() == selected)
			return dao.selectRankSexALL();
		return null;
	}
}
