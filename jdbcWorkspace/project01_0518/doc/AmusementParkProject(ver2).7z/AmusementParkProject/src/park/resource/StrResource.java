package park.resource;

public enum StrResource {
	REQUEST_SUCCESS(200, "성공적으로 처리되었습니다."), REQUEST_FAILED(500, "요청에 실패하였습니다."),

	INSERT_CUSTOMER(1, "INSERT INTO customer VALUES(null, ?, ?)"),
	INSERT_USELIST(2, "INSERT INTO uselist VALUES(null, ?, ?, ?, ?)"),

	UPDATE_CUSTOMER(3, "UPDATE customer SET sex = ?, age = ? WHERE no = ?"),

	DELETE_USELIST(4, "DELETE FROM uselist WHERE customer_no = ? AND attraction_no = ?"),
	
	SELECT_CUSTOMER(5, "SELECT * FROM customer where no = ?"), 
	SELECT_ATTREACTION(6, "SELECT * FROM attraction where no = ?"),
	
	SELECT_USELIST_ALL(7, "SELECT * FROM uselist"),
	SELECT_ATTREACTION_ALL(8, "SELECT * FROM attraction"),
	
	//분석
	SELECT_RANK_ATTR(9, "SELECT * FROM attraction"),
	SELECT_RANK_AGE(10, "SELECT * FROM attraction"),
	SELECT_RANK_SEX(11, "SELECT * FROM attraction");


	private int intValue;
	private String strValue;

	private StrResource(int intValue, String strValue) {
		this.intValue = intValue;
		this.strValue = strValue;
	}

	public int getIntValue() {
		return intValue;
	}

	public String getStrValue() {
		return strValue;
	}

}
