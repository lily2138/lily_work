package park.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import park.vo.Attraction;
import park.vo.Customer;
import park.vo.UseList;

public interface DefaultDao {
	public Connection getConnect() throws SQLException;

	public void closeAll(PreparedStatement ps, Connection conn) throws SQLException;

	public void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException;

	int insertCustomer(Customer vo) throws SQLException;

	int insertUseList(UseList vo) throws SQLException;

	int updateCustomer(Customer vo) throws SQLException;

	int deleteUseList(int custNo, int attrNo) throws SQLException;

	Customer selectCustomer(int id) throws SQLException;

	Attraction selectAttraction(int id) throws SQLException;

	ArrayList<Attraction> selectAttractionALL() throws SQLException;

	ArrayList<UseList> selectUseListALL() throws SQLException;

	ArrayList<Attraction> selectRankAttrALL() throws SQLException;

	ArrayList<Attraction> selectRankAgeALL() throws SQLException;

	ArrayList<Attraction> selectRankSexALL() throws SQLException;
}
