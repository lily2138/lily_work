package park.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import park.resource.StrResource;
import park.vo.Attraction;
import park.vo.Customer;
import park.vo.UseList;

public class DefaultDaoImpl implements DefaultDao {

	private static DefaultDaoImpl dao = new DefaultDaoImpl();

	private DefaultDaoImpl() {

	}

	public static DefaultDaoImpl getInstance() {
		return dao;
	}

	@Override
	public Connection getConnect() throws SQLException {
		Connection conn = null;
		try {
			Properties p = new Properties();
			p.load(new FileInputStream("src/config/jdbc.properties"));
			String driverName = p.getProperty("jdbc.mysql.driver");
			String url = p.getProperty("jdbc.mysql.url");
			String user = p.getProperty("jdbc.mysql.user");
			String pass = p.getProperty("jdbc.mysql.pass");
			Class.forName(driverName);
			conn = DriverManager.getConnection(url, user, pass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public void closeAll(PreparedStatement ps, Connection conn) throws SQLException {
		if (ps != null)
			ps.close();
		if (conn != null)
			conn.close();
	}

	@Override
	public void closeAll(ResultSet rs, PreparedStatement ps, Connection conn) throws SQLException {
		if (rs != null)
			rs.close();
		closeAll(ps, conn);
	}

	@Override
	public int insertCustomer(Customer vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.INSERT_CUSTOMER.getStrValue());
			ps.setString(1, vo.getSex());
			ps.setInt(2, vo.getAge());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public int insertUseList(UseList vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.INSERT_USELIST.getStrValue());
			ps.setInt(1, vo.getCustNo());
			ps.setInt(2, vo.getAttrNo());
			ps.setString(3, vo.getUseDate());
			ps.setInt(4, vo.getStatus());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public int updateCustomer(Customer vo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.UPDATE_CUSTOMER.getStrValue());
			ps.setString(1, vo.getSex());
			ps.setInt(2, vo.getAge());
			ps.setInt(3, vo.getCustNo());
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	// alter table fix add constraint employee_no foreign key (employee_no)
	@Override
	public int deleteUseList(int custNo, int attrNo) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnect();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(StrResource.DELETE_USELIST.getStrValue());
			ps.setInt(1, custNo);
			ps.setInt(2, attrNo);
			ps.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			conn.rollback();
			return StrResource.REQUEST_FAILED.getIntValue();
		} finally {
			conn.setAutoCommit(true);
			closeAll(ps, conn);
		}
		return StrResource.REQUEST_SUCCESS.getIntValue();
	}

	@Override
	public Customer selectCustomer(int id) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Customer customer = null;

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_CUSTOMER.getStrValue());
		ps.setInt(1, id);
		rs = ps.executeQuery();
		if (rs.next())
			customer = new Customer(rs.getInt(1), rs.getString(2), rs.getInt(3));
		closeAll(rs, ps, conn);
		return customer;
	}

	@Override
	public Attraction selectAttraction(int id) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Attraction attraction = null;

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_ATTREACTION.getStrValue());
		ps.setInt(1, id);
		rs = ps.executeQuery();
		if (rs.next())
			attraction = new Attraction(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5));
		closeAll(rs, ps, conn);
		return attraction;
	}

	@Override
	public ArrayList<UseList> selectUseListALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<UseList> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_USELIST_ALL.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new UseList(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getInt(5)));
		closeAll(rs, ps, conn);
		return arr;
	}

	@Override
	public ArrayList<Attraction> selectAttractionALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Attraction> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_ATTREACTION_ALL.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Attraction(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5)));
		closeAll(rs, ps, conn);
		return arr;
	}

	@Override
	public ArrayList<Attraction> selectRankAttrALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Attraction> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_RANK_ATTR.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Attraction(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5)));
		closeAll(rs, ps, conn);
		return arr;
	}
	@Override
	public ArrayList<Attraction> selectRankAgeALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Attraction> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_RANK_AGE.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Attraction(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5)));
		closeAll(rs, ps, conn);
		return arr;
	}

	@Override
	public ArrayList<Attraction> selectRankSexALL() throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Attraction> arr = new ArrayList<>();

		conn = getConnect();
		ps = conn.prepareStatement(StrResource.SELECT_RANK_SEX.getStrValue());
		rs = ps.executeQuery();
		while (rs.next())
			arr.add(new Attraction(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5)));
		closeAll(rs, ps, conn);
		return arr;
	}
}
