package curriculum.exception;

public class StdIdNullException {

}
