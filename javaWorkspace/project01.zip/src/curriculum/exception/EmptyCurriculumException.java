package curriculum.exception;

public class EmptyCurriculumException {

}
