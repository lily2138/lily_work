package curriculum.exception;

public class NullCurriculumException {

}
