package curriculum.exception;

public class MissmatchCurriculumException {

}
