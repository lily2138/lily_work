package curriculum.exception;

public class ScoreException {

}
